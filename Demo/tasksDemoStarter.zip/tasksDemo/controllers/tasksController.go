package controllers

import (
	"net/http"
)

// Import templates

/*
Function to retrieve all tasks and show on index page
*/
func Index(w http.ResponseWriter, r *http.Request) {

}

/*
Function to display form to create new task
*/
func New(w http.ResponseWriter, r *http.Request) {
	
}

/*
Function to create a new task
*/
func Create(w http.ResponseWriter, r *http.Request) {
	
}

/*
Function to delete a task
*/
func Delete(w http.ResponseWriter, r *http.Request) {
	
}

/*
Function to display form with retrieved values
*/
func Retrieve(w http.ResponseWriter, r *http.Request) {
	
}

/*
Function to update task
*/
func Update(w http.ResponseWriter, r *http.Request) {
	
}
