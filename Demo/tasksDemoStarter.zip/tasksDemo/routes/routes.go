package routes

func LoadRoutes() {

}
