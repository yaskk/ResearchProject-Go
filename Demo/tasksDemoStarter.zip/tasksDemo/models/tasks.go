package models

type Task struct {
}

func ShowAllTasks() []Task {

}

/*
Function to create a new task
*/
func CreateTask(title, description string, priority int) {

}

/*
Function to delete a specific task through its ID
*/
func DeleteTask(id string) {

}

/*
Function to retrieve data of a specific task
*/
func RetrieveTask(id string) Task {

}

/*
Function to update data of a specific task
*/
func UpdateTask(id int, title, description string, priority int) {

}
