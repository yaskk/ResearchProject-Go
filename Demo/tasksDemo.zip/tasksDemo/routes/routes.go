package routes

import (
	"net/http"

	"tasksDemo/controllers"
)

func LoadRoutes() {
	// Serve static files (css)
	fs := http.FileServer(http.Dir("templates/css"))
	http.Handle("/css/", http.StripPrefix("/css/", fs))

	// Define routes
	http.HandleFunc("/", controllers.Index)
	http.HandleFunc("/new", controllers.New)
	http.HandleFunc("/create", controllers.Create)
	http.HandleFunc("/delete", controllers.Delete)
	http.HandleFunc("/edit", controllers.Retrieve)
	http.HandleFunc("/update", controllers.Update)
}
