package db

import (
	"database/sql"

	_ "github.com/go-sql-driver/mysql"
)

func ConnectToDatabase() *sql.DB {
	// Create connection
	con := "dev:dev1234@/todo_list"

	// Open connection
	db, err := sql.Open("mysql", con)

	// Check errors
	if err != nil {
		panic(err.Error()) // Stops the program execution
	}

	return db
}
