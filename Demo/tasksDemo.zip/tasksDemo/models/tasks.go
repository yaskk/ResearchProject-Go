package models

import "tasksDemo/db"

type Task struct {
	Id          int
	Title       string
	Description string
	Priority    int
}

func ShowAllTasks() []Task {
	// Connect to DB
	db := db.ConnectToDatabase()

	// Retrieve all tasks
	allTasks, err := db.Query("SELECT * FROM tasks ORDER BY id")

	// Check for errors
	if err != nil {
		panic(err.Error())
	}

	// Create a single task and a list of tasks
	t := Task{}
	tasks := []Task{}

	// Loop to retrieve tasks from DB
	for allTasks.Next() {
		// Method 1
		var id, priority int
		var title, description string

		err = allTasks.Scan(&id, &title, &description, &priority)

		if err != nil {
			panic(err.Error())
		}

		// Set the values for the task
		t.Id = id
		t.Title = title
		t.Description = description
		t.Priority = priority

		// Method 2
		// err = allTasks.Scan(&t.Id, &t.Title, &t.Description, &t.Priority)

		// if err != nil {
		//     panic(err.Error())
		// }

		// For both methods
		// Add task to tasks list
		tasks = append(tasks, t)
	}

	// Close the connection
	defer db.Close()

	return tasks
}

/*
   Function to create a new task
*/
func CreateTask(title, description string, priority int) {
	// Connect to DB
	db := db.ConnectToDatabase()

	// Prepared statement to insert new task to DB
	insertTask, err := db.Prepare("INSERT INTO tasks(title, description, priority) VALUES (?,?,?)")

	// Check for errors
	if err != nil {
		panic(err.Error())
	}

	// Execute statement
	insertTask.Exec(title, description, priority)

	// Close the connection
	defer db.Close()
}

/*
   Function to delete a specific task through its ID
*/
func DeleteTask(id string) {
	// Connect to DB
	db := db.ConnectToDatabase()

	// Prepared statement to delete task
	deleteTask, err := db.Prepare("DELETE FROM tasks WHERE id = ?")

	// Check for errors
	if err != nil {
		panic(err.Error())
	}

	// Execute statement
	deleteTask.Exec(id)

	// Close the connection
	defer db.Close()
}

/*
   Function to retrieve data of a specific task
*/
func RetrieveTask(id string) Task {
	// Connect to DB
	db := db.ConnectToDatabase()

	// Query to retrieve task
	retrievedTask, err := db.Query("SELECT * FROM tasks WHERE id = ?", id)

	// Check for errors
	if err != nil {
		panic(err.Error())
	}

	// Store the data retrieved from DB
	task := Task{}

	for retrievedTask.Next() {
		// Method 1
		// var id, priority int
		// var title, description string

		// err = retrievedTask.Scan(&id, &title, &description, &priority)

		// if err != nil {
		// 	panic(err.Error())
		// }

		// // Set the values for the task
		// task.Id = id
		// task.Title = title
		// task.Description = description
		// task.Priority = priority

		// Method 2
		// If we choose this method, we need to follow the same order in the struct
		err = retrievedTask.Scan(&task.Id, &task.Title, &task.Description, &task.Priority)

		if err != nil {
			panic(err.Error())
		}
	}

	// Close the connection
	defer db.Close()

	return task
}

/*
   Function to update data of a specific task
*/
func UpdateTask(id int, title, description string, priority int) {
	// Connect to DB
	db := db.ConnectToDatabase()

	// Prepared statement to update task
	updateProduct, err := db.Prepare("UPDATE tasks SET title = ?, description = ?, priority = ? WHERE id = ?")

	// Check for errors
	if err != nil {
		panic(err.Error())
	}

	// Execute statement
	updateProduct.Exec(title, description, priority, id)

	// Close the connection
	defer db.Close()
}
