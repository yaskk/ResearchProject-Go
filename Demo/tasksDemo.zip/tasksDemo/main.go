package main

import (
	"log"
	"net/http"

	"tasksDemo/routes"
)

func main() {
	// Load routes
	routes.LoadRoutes()

	// Print port
	log.Println("Listening on port 9090")

	// Create server
	http.ListenAndServe(":9090", nil)

}
