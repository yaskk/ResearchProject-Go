package controllers

import (
	"log"
	"net/http"
	"strconv"
	"text/template"

	"tasksDemo/models"
)

// Import templates
var temp = template.Must(template.ParseGlob("templates/*.html"))

/*
Function to retrieve all tasks and show on index page
*/
func Index(w http.ResponseWriter, r *http.Request) {
	allTasks := models.ShowAllTasks()

	// Show template
	temp.ExecuteTemplate(w, "Index", allTasks)
}

/*
Function to display form to create new task
*/
func New(w http.ResponseWriter, r *http.Request) {
	// Show template
	temp.ExecuteTemplate(w, "Create", nil)
}

/*
Function to create a new task
*/
func Create(w http.ResponseWriter, r *http.Request) {
	// Check if it is a POST
	if r.Method == "POST" {
		// Retrieve data from form
		title := r.FormValue("title")
		description := r.FormValue("description")
		priority := r.FormValue("priority")

		// Convert priority to int
		convertedPriority, err := strconv.Atoi(priority)
		// Check for errors
		if err != nil {
			log.Println("Something went wrong when trying to convert priority:", err)
		}

		// Create new task
		models.CreateTask(title, description, convertedPriority)
	}

	// Redirect to index
	http.Redirect(w, r, "/", 301)
}

/*
Function to delete a task
*/
func Delete(w http.ResponseWriter, r *http.Request) {
	// Retrieve ID from the URL
	taskId := r.URL.Query().Get("id")

	// Delete task
	models.DeleteTask(taskId)

	// Redirect to index
	http.Redirect(w, r, "/", 301)
}

/*
Function to display form with retrieved values
*/
func Retrieve(w http.ResponseWriter, r *http.Request) {
	// Retrieve ID from the URL
	taskId := r.URL.Query().Get("id")

	// Retrieve data
	task := models.RetrieveTask(taskId)

	// Show template with task
	temp.ExecuteTemplate(w, "Edit", task)
}

/*
Function to update task
*/
func Update(w http.ResponseWriter, r *http.Request) {
	// Check if it is a POST
	if r.Method == "POST" {
		// Retrieve data from form
		id := r.FormValue("id")
		title := r.FormValue("title")
		description := r.FormValue("description")
		priority := r.FormValue("priority")

		// Convert id and priority to int
		convertedId, err := strconv.Atoi(id)
		// Check for errors
		if err != nil {
			log.Println("Something went wrong when trying to convert ID:", err)
		}

		convertedPriority, err := strconv.Atoi(priority)
		// Check for errors
		if err != nil {
			log.Println("Something went wrong when trying to convert priority:", err)
		}

		// Create new task
		models.UpdateTask(convertedId, title, description, convertedPriority)
	}

	// Redirect to index
	http.Redirect(w, r, "/", 301)
}
